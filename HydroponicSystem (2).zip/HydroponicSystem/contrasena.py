import sys
import bcrypt
import base64
from cryptography.fernet import Fernet
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QLabel, QLineEdit, QPushButton, QMessageBox, 
                             QTabWidget, QTextEdit, QCheckBox)
from PyQt5.QtCore import Qt

class PasswordManager(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gestor de Contraseñas")
        self.setGeometry(100, 100, 600, 400)
        
        # Configuración
        self.password_file = "passwords.dat"
        self.master_key = None
        
        # Crear pestañas
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        
        # Pestaña de inicio de sesión
        self.login_tab = QWidget()
        self.setup_login_tab()
        self.tabs.addTab(self.login_tab, "Iniciar Sesión")
        
        # Pestaña principal (se activa después del login)
        self.main_tab = QWidget()
        self.setup_main_tab()
        
        # Ocultar pestaña principal inicialmente
        self.tabs.setTabEnabled(1, False)
    
    def setup_login_tab(self):
        layout = QVBoxLayout()
        
        # Campo para la clave maestra
        self.master_password_input = QLineEdit()
        self.master_password_input.setPlaceholderText("Ingrese su clave maestra")
        self.master_password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(QLabel("Clave Maestra:"))
        layout.addWidget(self.master_password_input)
        
        # Botón de login
        self.login_btn = QPushButton("Iniciar Sesión")
        self.login_btn.clicked.connect(self.authenticate)
        layout.addWidget(self.login_btn)
        
        # Botón de registro (para primera vez)
        self.register_btn = QPushButton("Registrar Nueva Clave Maestra")
        self.register_btn.clicked.connect(self.register)
        layout.addWidget(self.register_btn)
        
        self.login_tab.setLayout(layout)
    
    def setup_main_tab(self):
        layout = QVBoxLayout()
        
        # Pestañas internas
        self.inner_tabs = QTabWidget()
        
        # Pestaña para guardar contraseñas
        self.save_tab = QWidget()
        self.setup_save_tab()
        self.inner_tabs.addTab(self.save_tab, "Guardar")
        
        # Pestaña para ver contraseñas
        self.view_tab = QWidget()
        self.setup_view_tab()
        self.inner_tabs.addTab(self.view_tab, "Ver")
        
        layout.addWidget(self.inner_tabs)
        self.main_tab.setLayout(layout)
    
    def setup_save_tab(self):
        layout = QVBoxLayout()
        
        # Campo para el servicio
        self.service_input = QLineEdit()
        self.service_input.setPlaceholderText("Ej: Gmail, Facebook")
        layout.addWidget(QLabel("Servicio:"))
        layout.addWidget(self.service_input)
        
        # Campo para usuario
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Usuario o email")
        layout.addWidget(QLabel("Usuario:"))
        layout.addWidget(self.username_input)
        
        # Campo para contraseña
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Contraseña")
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(QLabel("Contraseña:"))
        layout.addWidget(self.password_input)
        
        # Checkbox para mostrar contraseña
        self.show_password_check = QCheckBox("Mostrar contraseña")
        self.show_password_check.stateChanged.connect(self.toggle_password_visibility)
        layout.addWidget(self.show_password_check)
        
        # Botón para guardar
        self.save_btn = QPushButton("Guardar")
        self.save_btn.clicked.connect(self.save_password)
        layout.addWidget(self.save_btn)
        
        self.save_tab.setLayout(layout)
    
    def setup_view_tab(self):
        layout = QVBoxLayout()
        
        # Lista de servicios
        self.service_list = QTextEdit()
        self.service_list.setReadOnly(True)
        layout.addWidget(QLabel("Contraseñas guardadas:"))
        layout.addWidget(self.service_list)
        
        # Botón para actualizar lista
        self.refresh_btn = QPushButton("Actualizar Lista")
        self.refresh_btn.clicked.connect(self.refresh_list)
        layout.addWidget(self.refresh_btn)
        
        # Botón para mostrar contraseña
        self.show_btn = QPushButton("Mostrar Contraseña")
        self.show_btn.clicked.connect(self.show_password)
        layout.addWidget(self.show_btn)
        
        self.view_tab.setLayout(layout)
    
    def toggle_password_visibility(self, state):
        if state == Qt.Checked:
            self.password_input.setEchoMode(QLineEdit.Normal)
        else:
            self.password_input.setEchoMode(QLineEdit.Password)
    
    def authenticate(self):
        password = self.master_password_input.text()
        if not password:
            QMessageBox.warning(self, "Error", "Ingrese una clave maestra")
            return
        
        try:
            with open("master.key", "rb") as f:
                hashed = f.read()
            
            if bcrypt.checkpw(password.encode(), hashed):
                # Generar clave de encriptación derivada de la contraseña maestra
                self.master_key = self.generate_encryption_key(password)
                self.tabs.setTabEnabled(1, True)
                self.tabs.setCurrentIndex(1)
                self.refresh_list()
            else:
                QMessageBox.warning(self, "Error", "Clave maestra incorrecta")
        except FileNotFoundError:
            QMessageBox.warning(self, "Error", "Primero debe registrar una clave maestra")
    
    def register(self):
        password = self.master_password_input.text()
        if not password:
            QMessageBox.warning(self, "Error", "Ingrese una clave maestra")
            return
        
        # Hash de la clave maestra con bcrypt
        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
        
        with open("master.key", "wb") as f:
            f.write(hashed)
        
        QMessageBox.information(self, "Éxito", "Clave maestra registrada correctamente")
    
    def generate_encryption_key(self, password):
        # Usamos la contraseña maestra para derivar una clave de encriptación
        # En producción, deberías usar un KDF como PBKDF2 o Argon2
        key = password.ljust(32)[:32].encode()  # Ajuste simple para demostración
        return base64.urlsafe_b64encode(key)
    
    def encrypt_password(self, password):
        f = Fernet(self.master_key)
        return f.encrypt(password.encode()).decode()
    
    def decrypt_password(self, encrypted_password):
        f = Fernet(self.master_key)
        return f.decrypt(encrypted_password.encode()).decode()
    
    def save_password(self):
        service = self.service_input.text()
        username = self.username_input.text()
        password = self.password_input.text()
        
        if not service or not password:
            QMessageBox.warning(self, "Error", "Ingrese servicio y contraseña")
            return
        
        # Encriptar la contraseña
        encrypted = self.encrypt_password(password)
        
        # Guardar en archivo
        with open(self.password_file, "a") as f:
            f.write(f"{service}|{username}|{encrypted}\n")
        
        QMessageBox.information(self, "Éxito", "Contraseña guardada correctamente")
        self.service_input.clear()
        self.username_input.clear()
        self.password_input.clear()
        self.refresh_list()
    
    def refresh_list(self):
        try:
            with open(self.password_file, "r") as f:
                entries = f.readlines()
            
            display_text = ""
            for entry in entries:
                service, username, _ = entry.strip().split("|")
                display_text += f"🔒 {service} - 👤 {username}\n"
            
            self.service_list.setPlainText(display_text.strip())
        except FileNotFoundError:
            self.service_list.setPlainText("No hay contraseñas guardadas")
    
    def show_password(self):
        selected = self.service_list.textCursor().selectedText()
        if not selected:
            QMessageBox.warning(self, "Error", "Seleccione un servicio")
            return
        
        try:
            service = selected.split("🔒 ")[1].split(" - 👤")[0].strip()
            username = selected.split("👤 ")[1].strip()
            
            with open(self.password_file, "r") as f:
                for line in f:
                    s, u, encrypted = line.strip().split("|")
                    if s == service and u == username:
                        password = self.decrypt_password(encrypted)
                        QMessageBox.information(
                            self, "Contraseña", 
                            f"Servicio: {service}\nUsuario: {username}\nContraseña: {password}"
                        )
                        return
            
            QMessageBox.warning(self, "Error", "No se encontró la contraseña")
        except:
            QMessageBox.warning(self, "Error", "Error al recuperar la contraseña")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PasswordManager()
    window.show()
    sys.exit(app.exec_())
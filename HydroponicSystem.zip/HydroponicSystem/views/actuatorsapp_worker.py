from PyQt5 import QtCore
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys


class ActuatorsAppWorker(QWidget):
    def __init__(self, ventana_login, embed=False):
        super().__init__(ventana_login)
        self.ventana_login = ventana_login
        
        self.init_ui()

    def init_ui(self):
        self.setStyleSheet("""
            QLabel#Title {
                font-size: 28px;
                font-weight: bold;
                color: white;
                margin-left: 15px;
            }
            QLabel#Subtitle {
                font-size: 16px;
                font-weight: bold;
                color: white;
            }
            QPushButton {
                padding: 8px 16px;
                border-radius: 20px;
                background-color: #7FD1B9;
                color: black;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #6fc9a9;
            }
        """)

        main_layout = QVBoxLayout(self)

        # --- Frame principal ---
        actuators_frame = QFrame()
        actuators_frame.setStyleSheet("background-color: #28243C; border-radius: 15px;")
        actuators_layout = QVBoxLayout(actuators_frame)
        actuators_layout.setContentsMargins(20, 40, 20, 20)

        # --- Título ---
        title_actuadores = QLabel("Control de Actuadores")
        title_actuadores.setObjectName("Title")

        # --- Layout horizontal para título y botón ---
        top_layout = QHBoxLayout()
        top_layout.addWidget(title_actuadores, alignment=Qt.AlignVCenter)
        top_layout.addStretch()
        
        # --- Contenedor para los actuadores ---
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
            }
            QScrollBar:vertical {
                width: 12px;
                background: #252535;
            }
            QScrollBar::handle:vertical {
                background: #4a4a5a;
                min-height: 20px;
                border-radius: 6px;
            }
        """)
        scroll_content = QWidget()
        scroll_content.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)

        # --- Agregar widgets al layout ---
        actuators_layout.addLayout(top_layout)

        # Espacio entre el título/botón y el listado de actuadores
        space_between = QWidget()
        space_between.setFixedHeight(30)
        actuators_layout.addWidget(space_between)

        actuators_layout.addWidget(scroll_area)

        self.actuators_list_layout = QVBoxLayout(scroll_content)
        scroll_content.setContentsMargins(0, 0, 0, 0)
        scroll_area.setContentsMargins(0, 0, 0, 0)
        self.actuators_list_layout.setContentsMargins(10, 10, 10, 10)
        self.actuators_list_layout.setSpacing(20)

        scroll_area.setWidget(scroll_content)

        main_layout.addWidget(actuators_frame)

        # --- Llenar actuadores de ejemplo ---
        self.populate_actuators()

    def populate_actuators(self):
        actuadores = [
            {"nombre": "Bomba Sumergible", "estado": True},
            {"nombre": "Bomba Peristáltica", "estado": False},
            {"nombre": "Válvula Solenoide", "estado": True},
            {"nombre": "Motor DC", "estado": False},
            {"nombre": "Calentador", "estado": True}
        ]

        for actuador in actuadores:
            # --- Frame exterior ---
            outer_frame = QFrame()
            outer_frame.setFixedHeight(75)
            outer_frame.setStyleSheet("""
                QFrame {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                        stop:0 #60D4B8, stop:1 #1E2233);
                    border-radius: 35px;
                    padding: 2px;
                }
            """)

            # --- Frame interior ---
            actuator_frame = QFrame()
            actuator_frame.setStyleSheet("""
                background-color: #1f2232;
                border-radius: 35px;
            """)
            actuator_frame.setFixedHeight(70)
            actuator_layout = QHBoxLayout(actuator_frame)
            actuator_layout.setContentsMargins(20, 10, 20, 10)

            # Indicador de estado
            status_indicator = QLabel()
            status_indicator.setFixedSize(18, 18)
            status_color = "#4CAF50" if actuador["estado"] else "#f44336"
            status_indicator.setStyleSheet(f"""
                background-color: {status_color};
                border-radius: 9px;
                border: 2px solid #ffffff;
            """)
            actuator_layout.addWidget(status_indicator)

            # Nombre del actuador
            name_label = QLabel(actuador["nombre"])
            name_label.setStyleSheet("color: white; font-weight: bold; font-size: 16px;")
            actuator_layout.addWidget(name_label)

            actuator_layout.addStretch()

            # Botones
            caracteristicas_button = QPushButton("Caracteristicas")
            caracteristicas_button.setStyleSheet("""
                QPushButton {
                    background-color: #fa7907;
                    color: white;
                    font-weight: bold;
                    border-radius: 14px;
                    padding: 8px;
                }
                QPushButton:hover {
                    background-color: #f38c30;
                }
            """)
            caracteristicas_button.setFixedWidth(170)

            buttons_layout = QHBoxLayout()
            buttons_layout.setSpacing(10)
            buttons_layout.addWidget(caracteristicas_button)

            actuator_layout.addLayout(buttons_layout)

            # Asignar el interior al exterior
            outer_layout = QVBoxLayout(outer_frame)
            outer_layout.setContentsMargins(0, 0, 0, 0)
            outer_layout.addWidget(actuator_frame)

            # Agregar al layout principal
            self.actuators_list_layout.addWidget(outer_frame)